module.exports = {
    printWidth: 80,
    semi: true,
    singleQuote: true,
    trailingComma: "es5",
    tabWidth: 4
};